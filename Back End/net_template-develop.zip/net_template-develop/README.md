SS.Template-Backend
