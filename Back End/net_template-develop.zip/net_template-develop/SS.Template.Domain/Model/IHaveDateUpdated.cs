using System;

namespace SS.Template.Domain.Model
{
    public interface IHaveDateUpdated
    {
        DateTime DateUpdated { get; set; }
    }
}
