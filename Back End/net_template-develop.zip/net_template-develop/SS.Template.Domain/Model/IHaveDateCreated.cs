using System;

namespace SS.Template.Domain.Model
{
    public interface IHaveDateCreated
    {
        DateTime DateCreated { get; set; }
    }
}
