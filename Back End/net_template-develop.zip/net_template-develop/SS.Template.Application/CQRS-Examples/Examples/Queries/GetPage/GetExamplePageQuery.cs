using SS.Template.Application.Queries;

namespace SS.Template.Application.Examples.Queries.GetPage
{
    public sealed class GetExamplePageQuery : PaginatedQuery<ExampleModel>
    {
    }
}
