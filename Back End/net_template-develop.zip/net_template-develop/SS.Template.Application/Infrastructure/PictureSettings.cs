namespace SS.Template.Application.Infrastructure
{
    public sealed class PictureSettings
    {
        public int MaxWidth { get; set; }

        public int MaxHeight { get; set; }
    }
}
