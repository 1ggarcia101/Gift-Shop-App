namespace SS.Template.Core.Persistence
{
    public interface IReadOnlyRepository : IRepositoryBase
    {
    }
}
