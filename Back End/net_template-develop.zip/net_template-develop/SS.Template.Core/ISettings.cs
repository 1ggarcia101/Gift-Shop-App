namespace SS.Template.Core
{
    public interface ISettings
    {
        void Validate();
    }
}
