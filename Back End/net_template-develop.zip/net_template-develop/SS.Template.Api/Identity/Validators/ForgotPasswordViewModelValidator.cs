using SS.Template.Api.Identity.Models;

namespace SS.Template.Api.Identity.Validators
{
    public sealed class ForgotPasswordViewModelValidator : EmailModelBaseValidator<ForgotPasswordViewModel>
    {
    }
}
