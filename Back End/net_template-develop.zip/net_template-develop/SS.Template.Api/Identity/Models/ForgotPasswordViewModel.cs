namespace SS.Template.Api.Identity.Models
{
    public class ForgotPasswordViewModel : EmailModelBase
    {
    }
}
