namespace SS.Template.Api.Identity.Models
{
    public class AuthenticatedModel
    {
        public bool IsAuthenticated { get; set; }
    }
}
